/* Utility to convert an xlinkit XML rule file into latex
   Mon Aug  5 15:29:48 EDT 2002 shimon - created
*/

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.RuntimeException;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**

   Pretty-printer (via latex) of xlinkit consistency rules.

   Requires Java 1.4 libraries (for XML stuff and regular-expression
   support).

   Given a rule file, produces LaTeX output containing information about the
   globalsets and rules in that file.  It produces a section for each rule
   including the rule's description, other header tags (including meta:
   tags), link generation status, and most importantly, a pretty math-mode
   version of the rule itself using proper logic operator and quantifier
   symbols, reasonably balanced parentheses, italics for variable names,
   typewriter font for tags in xpath expressions, bold font for xpath
   function calls, roman font and curly quotes for string literals, and
   probably more that I can't remember.  
   
   It has some very rudimentary support for growing things down the page
   rather than across when they get long, but the measure of "long" is
   pretty arbitrary, since I can't predict how big the math will look on the
   printed page.  Unfortunately, TeX doesn't have a clever
   math-formula-wrapping algorithm, just a very good one for text, so
   instead of a clever algorithm written by someone smart and famous, you
   have a stupid algorithm written by me.

   I'm a bit surprised that this seems to work, because it is based on a
   very dumb recursive-descent-style document tree traversal, copious
   regex-subsitutions, and horrendous LaTeX acrobatics.  Chances are that if
   your rule-coding style is very different from mine, parts of your code
   may very unexpectedly turn into strange mathematical symbols.  I hope
   this doesn't happen, but consider yourself warned.  Tweaking this program
   to output better LaTeX for your particular ruleset is recommended because
   it will look nicer, but also recommened against because this program is
   not nice looking itself.

*/
public class Rule2Latex {

    /** DocumentBuilder factory. */
    protected DocumentBuilderFactory dbf;

    /** DocumentBuilder object. */
    protected DocumentBuilder db;

    /** Rule set */
    protected Document rules;
    
    /**
     * Creates a new <code>Rule2Latex</code> instance for the specified rule
     * file.
     */
    public Rule2Latex(String filename) throws FileNotFoundException {
        this(new FileReader(filename));
    }
    
    /**
     * Creates a new <code>Rule2Latex</code> instance reading rule XML from
     * the reader.
     */
    public Rule2Latex(Reader r) {
        dbf = DocumentBuilderFactory.newInstance();
        //dbf.setNamespaceAware(true);
        dbf.setValidating(false);
        dbf.setIgnoringElementContentWhitespace(true);
		
        try {
            db = dbf.newDocumentBuilder();
        
            rules = db.parse(new InputSource(r));

        } catch(Exception pce){
            pce.printStackTrace();
            System.exit(1);
        }
        
    }

    /**
     * Frontend for more specific parse/pretty-print methods.
     *
     * @param n a <code>Node</code> to parse.
     * @return a <code>String</code> LaTeX fragment.
     */
    protected String parse(Node n) {
        if(n == null) {
            return "";
        }
        

        switch (n.getNodeType()) {

        case Node.ATTRIBUTE_NODE:
            return parseAttr((Attr) n);
            
        case Node.CDATA_SECTION_NODE:
        case Node.TEXT_NODE:
            return parseContent(n);

        case Node.DOCUMENT_NODE:
            return parseDoc((Document) n);

        case Node.ELEMENT_NODE:
            return parseElement((Element) n);

        case Node.COMMENT_NODE:
            return "% comment node ignored";

        case Node.DOCUMENT_FRAGMENT_NODE:
        case Node.DOCUMENT_TYPE_NODE:
        case Node.ENTITY_NODE:
        case Node.ENTITY_REFERENCE_NODE:
        case Node.NOTATION_NODE:
        case Node.PROCESSING_INSTRUCTION_NODE:
            return "% unexpected node type\n";
        }

        throw new RuntimeException("No way in HELL");
    }


    protected String parseAttr(Attr attr) {
        String name = attr.getName();
        String value = attr.getValue();
            
        return " {\\tt " + escape(name) + "} = " + escape(value);
    }

    protected String parseContent(Node n) {
        return escape(n.getNodeValue());
    }
    
    protected String parseDoc(Document d) {
        StringBuffer result = new StringBuffer();

        boolean landscape = false;

        result.append("\\documentclass[10pt]{article}\n");
        result.append("\\usepackage{geometry}\n");

        if(landscape) {
            result.append("\\geometry{verbose,letterpaper," + 
                         "tmargin=1in,bmargin=1in,lmargin=1in,rmargin=1in}\n");
            result.append("\\usepackage{landscape}\n"); 
        } else {
            result.append("\\geometry{verbose,letterpaper," + 
                    "tmargin=.8in,bmargin=.8in,lmargin=.3in,rmargin=1.3in}\n");
        }
        result.append("\\title{xlinkit Consistency Rules}\n");
        result.append("\\author{Generated by Rule2Latex by Shimon Rura}\n");
        result.append("\\begin{document}\n");
        result.append("\\setlength\\parindent{0pt}\n");
        result.append("\\setlength\\parskip{\\medskipamount}\n");
        result.append("\\maketitle\n\\tableofcontents\n\\newpage\n");

        // now parse children: globalset & consistencyrule elements
        NodeList crs = rules.getFirstChild().getChildNodes();

        for(int i = 0; i < crs.getLength(); i++) {
            result.append(parse(crs.item(i)));
        }
        
        result.append("\\end{document}\n");

        return result.toString();
    }


    protected boolean hasGlobals = false;
    protected boolean hasRules = false;

    protected String parseElement(Element e) {

        String eltname = e.getTagName();

        StringBuffer result = new StringBuffer();
        
        if(eltname.equals("globalset")) {

            if(!hasGlobals) {
                hasGlobals = true;
                result.append("\n\\section*{Global Sets}\n");
            }
            
            result.append("\n\\[ " + 
                          e.getAttribute("id") + " = " +
                          parsePath(e.getAttribute("xpath")) +
                          " \\]");
            
        } else if(eltname.equals("consistencyrule")) {

            if(!hasRules) {
                hasRules = true;
                result.append("\n\\section{Consistency Rules}\n");
            }
            
            result.append("\n\\subsection{" + 
                          escape(
                                 e.getAttribute("id")
                                 .replaceAll("([a-z])([A-Z])","$1 $2")
                                 ) + "}\n\n" +
                          "{\\Large " +
                          
                          escape(e.getElementsByTagName("description")
                                 .item(0).getFirstChild()
                                 .getNodeValue()) +

                          " }" +
                          parseChildren(e) +
                          "\n"
                          );
            
            result.append("%% end rule\n");
            
        } else if(eltname.equals("header")) {
            // return content
            return parseChildren(e);
            
        } else if(eltname.equals("description")) {
            // return nothing - handled specially in consistencyrule
            
        } else if(eltname.equals("linkgeneration")) {
            result.append("\n\\subsubsection*{Link Generation}\n" +
                          "\\begin{itemize}\n");
            result.append(parseChildren(e));
            result.append("\n\\end{itemize}\n");
            
        } else if(eltname.equals("consistent") || 
                  eltname.equals("inconsistent") ||
                  eltname.equals("eliminatesymmetry")) {

            result.append("\n\\item {\\bf " + eltname + ":} " +
                          e.getAttribute("status") + "\n");

        } else if(eltname.equals("forall")) {
            result.append(//"\n\\[ \\begin{array}{l}\n" + 
                          "\\begin{minipage}[h]{\\textwidth}\n" +
                          parseLogicElt(e, false) +
                          "\\end{minipage}"
                          ); //+ 
                          //" \\end{array}\n\\]\n");
            
        } else {
            result.append("\n{\\bf " + eltname + ":} ");
            
            // first print attrs
            NamedNodeMap attrs = e.getAttributes();
                            
            if(attrs.getLength() > 0) {
                result.append(" [");
            }

            for(int k = 0; k < attrs.getLength(); k++) {
                Attr attr = (Attr) attrs.item(k);
                String name = attr.getName();
                String value = attr.getValue();
                
                result.append(" {\\tt " +
                              escape(name) + "}=" +
                              escape(value));
            }
            
            if(attrs.getLength() > 0) {
                result.append(" ]");
            }

            result.append(parseChildren(e));
        }
        
        return result.toString();
    }

    
    /**
     * Return latex code for a logic element (forall, exists, equal,
     * notequal, same, intersect, subset, and, or, implies, not).
     *
     * @param e a logic <code>Element</code>
     * @param isNested true if return value is to be used inside a math context
     */
    protected String parseLogicElt(Element e, boolean isNested) {
        if(e == null) return "";

        String eltname = e.getTagName();

        StringBuffer result = new StringBuffer();

        if(!isNested) result.append(" \\[\n");
        
        if(eltname.equals("forall") ||
           eltname.equals("exists")) {
            result.append("\\"+eltname + " \\  " + e.getAttribute("var") +
                          " \\in " + parsePath(e.getAttribute("in")) + 
                          (isNested ? "\\\\\n" : "\n"));
            if(!isNested) result.append(" \\]\n");

            result.append(parseLogicElt(getFirstChildElt(e),isNested));

        } else if(eltname.equals("or") || 
                  eltname.equals("and") ||
                  eltname.equals("implies")) {
            String operator = " ? ";

            if(eltname.equals("or")) operator = " \\bigvee ";
            //if(eltname.equals("and")) operator = " \\bigwedge ";
            if(eltname.equals("and")) operator = " \\mathbf{\\&} "; 
            if(eltname.equals("implies")) operator = " \\Downarrow ";

            result.append("\\left(\\begin{array}{c}\n");
            result.append(parseLogicElt(getFirstChildElt(e),true) +
                          " \\\\ " + operator + " \\\\ " + 
                          parseLogicElt(getSecondChildElt(e),true) +
                          (isNested ? "\\\\\n" : "\n"));
            result.append("\\end{array} \\right)\n");
            if(!isNested) result.append(" \\]\n");

        } else if(eltname.equals("equal") ||
                  eltname.equals("notequal") ||
                  eltname.equals("same")) {            
            String operator = " ? ";
            
            if(eltname.equals("equal")) {
                operator = " = ";
            } else if(eltname.equals("notequal")) {
                operator = " \\neq ";
            } else if(eltname.equals("same")) {
                operator = " \\equiv ";
            }
            
            String op1 = e.getAttribute("op1");
            String op2 = e.getAttribute("op2");

            result.append(parsePath(op1) + operator + parsePath(op2));

            if(!isNested) result.append(" \\]\n");

        } else if(eltname.equals("not")) {
            result.append("\\lnot \\left(\\begin{array}{c}\n");
            result.append(parseLogicElt(getFirstChildElt(e),true) +
                          (isNested ? "\\\\\n" : "\n"));
            result.append("\\end{array} \\right)\n");
            if(!isNested) result.append(" \\]\n");

        } else {
            result.append(" ?: " + eltname + " :? \n");
            if(!isNested) result.append(" \\]\n");
        }
        

        return result.toString();
    }

    /** return first child of n which is an Element, or null if no children
     * are elements. */
    protected Element getFirstChildElt(Node n) {

        NodeList kids = n.getChildNodes();

        for(int i = 0; i < kids.getLength(); i++) {
            Node kid = kids.item(i);

            if(kid.getNodeType() == Node.ELEMENT_NODE) {
                return (Element) kid;
            }
        }

        return null;
    }

    /** return second child of n which is an Element, or null if 1 or fewer
     * children are elements. */
    protected Element getSecondChildElt(Node n) {

        NodeList kids = n.getChildNodes();

        boolean seenFirst = false;

        for(int i = 0; i < kids.getLength(); i++) {
            Node kid = kids.item(i);

            if(kid.getNodeType() == Node.ELEMENT_NODE) {
                if(!seenFirst) {
                    seenFirst = true;
                    continue;
                }
                
                return (Element) kid;
            }
        }

        return null;
    }

    protected String parseChildren(Node n) {
        StringBuffer result = new StringBuffer();

        NodeList kids = n.getChildNodes();

        for(int i = 0; i < kids.getLength(); i++) {
            result.append(parse(kids.item(i)));
        }

        return result.toString();
    }

    /** Quote the string for LaTeX -- incomplete */
    public String escape(String s) {
        s.replaceAll("&", "\\&");

        return s;
    }

    /** Convert the given xpath expression to LaTeX */
    public String parsePath(String path) {
        boolean longMode = false;

        if(path.length() > 95) longMode = true;

        //String result = path.length() + ": " + path;
        String result = path;
        
        //result = result.replaceAll("\\$","\\\\mathit ");
        result = result.replaceAll("\\$([A-Za-z0-9\\-]+)","\\\\mathit{$1}");
        result = result.replaceAll("'([A-Za-z0-9\\-]+)'","\\\\mathrm{``$1\"}");
        result = result.replaceAll("([/@:])([A-Za-z0-9\\-]+)",
                                   "$1\\\\mathtt{$2}");
        result = result.replaceAll("([A-Za-z0-9\\-]+)\\(",
                                   "\\\\mathbf{$1}(");
        //result = result.replaceAll("(\\w+)","\\\\mathtt{$1}");

        result = result.replaceAll("\\("," \\\\left(\\\\begin{array}{l}\n");
        result = result.replaceAll("\\)"," \\\\end{array}\\\\right) ");


        result = result.replaceAll("!="," \\\\neq ");
        result = result.replaceAll("-","\\\\!\\\\!-\\\\!\\\\!");
        
        if(!longMode) {
            
            result = result.replaceAll("\\|"," \\\\ \\\\cup \\\\ \n");

            result = result.replaceAll("\\sor\\s"," \\\\ \\\\lor \\\\ \n");
            result = result.replaceAll("\\sand\\s",
                                       " \\\\ \\\\mathbf{\\\\&} \\\\ \n");

            result = result.replaceAll("\\["," \\\\left[ ");
            result = result.replaceAll("\\]"," \\\\right] ");

            
            //return "\\mathtt{" +  result + "}";
            return result;

        } else {

            result = result.replaceAll("\\["," \\\\left[ \\\\begin{array}{l}\n");
            result = result.replaceAll("\\]"," \\\\end{array} \\\\right] ");

            result = result.replaceAll("\\|"," \\\\  \\\\cup \\\\\\\\\n"); 
            result = result.replaceAll("="," \\\\  = \\\\\\\\\n"); 
            //result = result.replaceAll("::"," \\\\ :: \\\\\\\\\n"); 
            result = result.replaceAll(",",", \\\\\\\\\n"); 
            result = result.replaceAll("::",":: \\\\\\\\\n"); 

            result = result.replaceAll("\\sor\\s"," \\\\ \\\\lor \\\\\\\\\n");
            result = result.replaceAll("\\sand\\s",
                                       " \\\\ \\\\mathbf{\\\\&} \\\\\\\\\n");

            
            return "\\left\\{ \\begin{array}{l}\n" + 
                //"\\mathtt{" +  result + "}" +
                result +
                //"\\end{array} \\right\\}";
                "\\end{array}\\right.";

        }
    }

    public void printLatex() {
        System.out.println(parse(rules));
    }

    public void printHTMLDesc() {
        NodeList descs = rules.getElementsByTagName("description");

        System.out.println("<ol>");

        for(int i = 0; i < descs.getLength(); i++) {
            Element desc = (Element) descs.item(i);

            NodeList kids = desc.getChildNodes();

            System.out.println("<li>");

            for(int j = 0; j < kids.getLength(); j++) {
                String v = kids.item(j).getNodeValue();
                if(v == null) continue;
                System.out.println(v);
            }
        }

        System.out.println("</ol>");
    }

    public static void main (String[] args) 
        throws FileNotFoundException
    {
        if(args.length < 1) {
            System.out.println("usage: Rule2Latex [-h] rule.xml");
            System.exit(1);
        }

        String xmlfile = args[0];
        if(args.length > 1) {
            xmlfile = args[1];
        }
        
        Rule2Latex r2l = new Rule2Latex(xmlfile);

        if(args.length > 1) {
            r2l.printHTMLDesc();
        } else {
            r2l.printLatex();
        }
    }
}
