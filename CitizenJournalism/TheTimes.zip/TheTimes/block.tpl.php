<?php // $Id: block.tpl.php,v 1.2 2008/08/12 16:44:42 jmburnz Exp $
/**
 * @file block.tpl.php
 *
 * Theme implementation to display a block.
 *
 * @see template_preprocess()
 * @see template_preprocess_block()
 *
 * The Times Theme based on Newswire by AdaptiveThemes.com
 * Modified by CS316 MHC
 *
 */
?>


<div id="block-<?php print $block->module .'-'. $block->delta; ?>" class="<?php if (($block->subject && strcmp($block->subject, "Search") != 0) 
          && ((strcmp($block->subject, "section_title") != 0))  && ((strcmp($block->subject, "More News") != 0)) ): ?>
    block<?php print $block_classes; ?><?php endif; ?>
    <?php if(($block->subject && strcmp($block->subject, "section_title") == 0)): ?> section-headings<?php endif; ?>">
  <div class="block-wrapper blockpadding">
    <?php if($block->subject && strcmp($block->subject, "More News") == 0): ?>
    <p style="color: #000000; font-variant: small-caps; font-weight: bold; font-size: larger; padding-bottom:-5px; margin-bottom: -3px; margin-top:-5px;">more news &raquo;</p>
    <?php endif; ?>
    <div class="<?php if($block->subject && strcmp($block->subject, "main_story") == 0){ print ""; } else{ print "content"; } ?>">

    <?php print $block->content; ?>
    </div>
  <?php print $edit_links; ?>
  </div> <!-- /block-wrapper -->
</div> <!-- /block -->  
