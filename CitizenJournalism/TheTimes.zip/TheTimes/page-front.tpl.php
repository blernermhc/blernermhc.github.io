<?php // $Id: page.tpl.php,v 1.9 2008/10/23 13:19:01 jmburnz Exp $ 
/**
 * @file page.tpl.php
 *
 * Theme implementation to display a single Drupal page.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 *
 * The Times Theme based on Newswire by AdaptiveThemes.com
 * Modified by CS316 MHC
 *
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language; ?>" xml:lang="<?php print $language->language; ?>">
<head>
  <title><?php print $head_title; ?></title>
  <?php print $head; ?>
  <?php print $styles; ?>
  <!--[if IE]>
    <link rel="stylesheet" href="<?php print $base_path . $directory; ?>/ie.css" type="text/css">
  <![endif]-->
  <?php if (!empty($suckerfish)): ?>
  <!--[if lte IE 6]>
    <script type="text/javascript" src="<?php print $base_path . $directory; ?>/js/suckerfish.js"></script>
  <![endif]-->
   <?php endif; ?>
  <?php print $scripts; ?>
  
  <script type="text/javascript">
    if (navigator.appName.indexOf('Microsoft') != -1)
    var browser = 'IE'

    if(browser=="IE")
    {
      document.write('<'+'link rel="stylesheet" href="ie.css" type="text/css" />');
    }  
  </script>

  
</head>
<body class="<?php print $body_class; ?>">
	
 <div id="container">
 
    <div id="header-col-wrapper">
		<div id="header_left" class = "width-10-190 padding-10">
			<?php print $header_left; ?>
		</div><!-- /header_left -->
		
		<div id="header_center" class = "width-28-550 padding-10">
			<?php if ($logo): ?>
		    <a href="/d"><img src = "<?php print $logo; ?>"></a>
			<?php endif ?>        
			<div style="text-align:center;" class="date"><?php print date("l F j, Y"); ?></div>
			<?php print $header_center; ?>	
		</div> <!-- /header_center -->
		
		<div id="header_right" class = "width-10-185">
			<?php print $header_right; ?>
		</div> <!-- /header_right -->
	</div>

	<div id="navigation-col-wrapper" class="last2 thin-top-border">
                <div id="section_bar" class = "floatleftinline width-38-745">
			 <div id="<?php print $primary_links ? 'primary-menu' : 'suckerfish' ; ?>" class="width-46-910">
                          <?php 
			  if ($primary_links) {
			    print theme('links', $primary_links); 
			  }		    
                          ?>
        </div> <!-- /primary -->
			<?php print $section_bar; ?>
		</div>
		<div id="search_bar" class = "floatright width-9-180">
			<?php print $search_bar; ?>
		</div>
	</div>

	<div id="main-col-wrapper" class="last2 doubled-top-border">
		<div id="headlines_left" class = "width-10-190 thin-right-border text">
			<?php print $headlines_left; ?>
		</div>
		<div id="main-section-wrapper" class = "floatleft text">		
			<div id="main_story_region" class = "width-18-350 doubled-bottom-border">
				<?php print $main_story_region; ?>
		
			</div>
			<div id="main-section2-wrapper" class="last2">
				<div id="headline_center_left" class = "width-9-175 thin-right-border text-small-main1">
				<?php print $headlines_center_left; ?>
				</div>
				<div id="headlines_center_right" class = "width-9-175 text">
				<?php print $headlines_center_right; ?>
				</div>
			</div>
		</div>
		<div id="more-news-wrapper" class = "floatleft thin-border">
			<div id="headlines_right" class = "width-9-175 text">
				<?php print $headlines_right; ?>
			</div>
			<div id="more_news_region" class = "width-9-175 last2 text border-top">
				<?php print $more_news_region; ?>
			</div>
		</div>
		<div id="block-wrapper" class="floatleft">
			<div id="block_right_top" class = "width-9-175 thin-bottom-border border-right text">
				<?php print $block_right_top; ?>
			</div>
			<div id="block_right_center" class = "width-9-175 thin-bottom-border border-right last2 text">
				<?php print $block_right_center; ?>
			</div>
			<div id="block_right_bottom" class = "width-9-175 last2 border-right text">
				<?php print $block_right_bottom; ?>
			</div>
		</div>
	</div> 
	
	<div id="bottom-col-wrapper" class="last2 doubled-top-border">
		<div id="section_headlines_1" class = "width-9-175 thin-right-border text">
			<?php print $section_headlines_1; ?>
		</div>
		<div id="section_headlines_2" class = "width-9-175 thin-right-border text">
			<?php print $section_headlines_2; ?>
		</div>
		<div id="section_headlines_3" class = "width-9-175 thin-right-border text">
			<?php print $section_headlines_3; ?>
		</div>
		<div id="section_headlines_4" class = "width-9-175 thin-right-border text">
			<?php print $section_headlines_4; ?>
		</div>
		<div id="bottom_block_region" class = "width-9-175" style="margin-left: 8px;">
			<?php print $bottom_block_region; ?>
		</div> 
	</div>
	
	<br/><br/><br/><br/><br /></br />
	<div id="links" class = "width-48-950 last2 thin-top-border" align="center">
			<?php print $links; ?>
	</div> 
	<div class="last2">
        <?php if(!$is_front){print $content;} ?>
	<?php print $closure ?>
	</div>
	<br/><br/>
  </div><!--- end layout -->
</body><!-- end body -->
</html><!-- end html -->