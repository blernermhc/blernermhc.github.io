<?php // $Id: page.tpl.php,v 1.9 2008/10/23 13:19:01 jmburnz Exp $ 
/**
 * @file page.tpl.php
 *
 * Theme implementation to display a single Drupal page.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 *
 *
 * The Times Theme based on Newswire by AdaptiveThemes.com
 * Modified by CS316 MHC
 *
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language; ?>" xml:lang="<?php print $language->language; ?>">
<head>
  <title><?php print $head_title; ?></title>
  <?php print $head; ?>
  <?php print $styles; ?>
  <!--[if IE]>
    <link rel="stylesheet" href="<?php print $base_path . $directory; ?>/ie.css" type="text/css">
  <![endif]-->
  <?php if (!empty($suckerfish)): ?>
  <!--[if lte IE 6]>
    <script type="text/javascript" src="<?php print $base_path . $directory; ?>/js/suckerfish.js"></script>
  <![endif]-->
   <?php endif; ?>
  <?php print $scripts; ?>
</head>
<body class="<?php print $body_class; ?>">
	
 <div id="container">
 
    <div id="header-col-wrapper">
		<div id="header_left" class = "width-10-190 padding-10">
			<?php print $header_left; ?>
		</div><!-- /header_left -->
		
		<div id="header_center" class = "width-28-550 padding-10">
			<?php if ($logo): ?>
		    <a href="/d"><img src = "<?php print $logo; ?>"></a>
			<?php endif ?>        
			<div style="text-align:center;" class="date"><?php print date("l F j, Y"); ?></div>
			<?php print $header_center; ?>	
		</div> <!-- /header_center -->
		
		<div id="header_right" class = "width-10-185">
			<?php print $header_right; ?>
		</div> <!-- /header_right -->
	</div>

	<div id="navigation-col-wrapper" class="last2 thin-top-border doubled-bottom-border2">
                <div id="section_bar" class = "floatleftinline width-38-745">
			 <div id="<?php print $primary_links ? 'primary-menu' : 'suckerfish' ; ?>" class="width-46-910">
                          <?php 
			  if ($primary_links) {
			    print theme('links', $primary_links); 
			  }		    
                          ?>
        </div> <!-- /primary -->
			<?php print $section_bar; ?>
		</div>
		<div id="search_bar" class = "floatright width-9-180">
			<?php print $search_bar; ?>
		</div>
	</div> 
		<div class="last2" style="padding-top:10px">
        <?php if(!$is_front){print $content;} ?>
	<?php print $closure ?>
	</div>
  </div><!--- end layout -->
</body><!-- end body -->
</html><!-- end html -->